from typing import TypedDict

class State(TypedDict):
    user_query: str
    route: str
    response: str