# from langgraph.graph import StateGraph, START, END
# from langgraph.checkpoint.memory import MemorySaver

# from app.state import State
# from app.router import router_node
# from app.dispatcher import dispatcher
# from app.load_agents import load_agents

# load_agents()

# builder = StateGraph(State)

# builder.add_node("router", router_node)
# builder.add_node("dispatcher", dispatcher)

# builder.add_edge(START, "router")
# builder.add_edge("router", "dispatcher")
# builder.add_edge("dispatcher", END)

# app = builder.compile(checkpointer=MemorySaver())

# if __name__ == "__main__":

#     print("\n=== MULTI AGENT SYSTEM READY ===\n")

#     config = {"configurable": {"thread_id": "user-1"}}

#     while True:
#         q = input("\nYou: ")
#         if q.lower() in ["exit", "quit"]:
#             break

#         res = app.invoke({"user_query": q}, config=config)
#         print("\nResponse:", res["response"])

#########
from langgraph.graph import StateGraph, START, END
from langgraph.checkpoint.memory import MemorySaver

from app.state import State
from app.router import router_node
from app.dispatcher import dispatcher
from app.load_agents import load_agents
from app.registry import AGENTS

# =========================================================
# AUTO LOAD ALL AGENTS
# =========================================================

load_agents()

# =========================================================
# BUILD LANGGRAPH
# =========================================================

builder = StateGraph(State)

builder.add_node(
    "router",
    router_node
)

builder.add_node(
    "dispatcher",
    dispatcher
)

builder.add_edge(
    START,
    "router"
)

builder.add_edge(
    "router",
    "dispatcher"
)

builder.add_edge(
    "dispatcher",
    END
)

# =========================================================
# COMPILE GRAPH
# =========================================================

app = builder.compile(
    checkpointer=MemorySaver()
)

# =========================================================
# MAIN LOOP
# =========================================================

if __name__ == "__main__":

    print("================================================")
    print("MULTI AGENT SYSTEM STARTED")
    print("Type 'exit' to quit")
    print("Type 'agents' to list all agents")
    print("================================================")

    config = {
        "configurable": {
            "thread_id": "user-session-1"
        }
    }

    while True:

        try:

            q = input("\nYou: ").strip()

            # =========================================
            # EMPTY INPUT
            # =========================================
            if not q:
                continue

            # =========================================
            # EXIT COMMAND
            # =========================================
            if q.lower() in ["exit", "quit"]:

                print("\nExiting system...")
                break

            # =========================================
            # LIST AGENTS COMMAND
            # =========================================
            if q.lower() in [
                "agents",
                "list agents",
                "show agents"
            ]:

                print("\n=========== AVAILABLE AGENTS ===========")

                for idx, name in enumerate(
                    AGENTS.keys(),
                    start=1
                ):
                    print(f"{idx}. {name}")

                print("========================================")

                continue

            # =========================================
            # PROCESS LANGGRAPH
            # =========================================

            result = app.invoke(
                {
                    "user_query": q
                },
                config=config
            )

            print(
                f"\nResponse: {result['response']}"
            )

        except KeyboardInterrupt:

            print("\n\nInterrupted by user")
            break

        except Exception as e:

            print(f"\nError: {str(e)}")