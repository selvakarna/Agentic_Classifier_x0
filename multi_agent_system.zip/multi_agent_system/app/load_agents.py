import pkgutil
import importlib
import app.agents as agents_pkg

def load_agents():
    for _, module_name, _ in pkgutil.iter_modules(agents_pkg.__path__):
        importlib.import_module(f"app.agents.{module_name}")