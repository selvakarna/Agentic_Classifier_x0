from app.registry import AGENTS

def dispatcher(state):

    route = state["route"]

    if route not in AGENTS:
        route = "general"

    return AGENTS[route](state)