AGENTS = {}

def agent(name):
    def wrapper(func):
        AGENTS[name] = func
        return func
    return wrapper