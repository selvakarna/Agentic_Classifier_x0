import asyncio

async def call_mcp(server_script, tool, args):

    from mcp import ClientSession, StdioServerParameters
    from mcp.client.stdio import stdio_client

    server = StdioServerParameters(command="python", args=[server_script])

    async with stdio_client(server) as (r, w):
        async with ClientSession(r, w) as session:
            await session.initialize()
            result = await session.call_tool(tool, args)

            if result.content:
                return result.content[0].text

            return str(result)