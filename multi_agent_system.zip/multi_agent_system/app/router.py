from app.config import llm
from app.registry import AGENTS

def router_node(state):

    agent_list = " | ".join(list(AGENTS.keys()))

    prompt = f"""
    Route into one of these agents:
    {agent_list} | general

    Query: {state['user_query']}
    """

    route = llm.invoke(prompt).content.strip().lower()

    return {"route": route}