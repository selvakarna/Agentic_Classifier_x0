import re, asyncio
from app.registry import agent
from app.mcp_client import call_mcp

@agent("calculator")
def calculator(state):

    nums = re.findall(r"\d+", state["user_query"])
    expr = f"{nums[0]} * {nums[1]}" if len(nums) >= 2 else "0"

    result = asyncio.run(call_mcp(
        "servers/calculator_agent.py",
        "calculate",
        {"expression": expr}
    ))

    return {"response": result}