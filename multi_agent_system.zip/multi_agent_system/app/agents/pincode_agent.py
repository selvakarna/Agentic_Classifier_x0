# import requests
# import re
# from app.registry import agent

# @agent("pincode")
# def pincode_agent(state):

#     text = state["user_query"]

#     match = re.search(r"\b\d{6}\b", text)

#     if not match:
#         return {"response": "Please provide a valid 6-digit PIN code."}

#     pin = match.group()

#     try:
#         url = f"https://api.postalpincode.in/pincode/{pin}"
#         res = requests.get(url, timeout=10)
#         data = res.json()

#         if data[0]["Status"] != "Success":
#             return {"response": f"No data found for PIN {pin}"}

#         post_office = data[0]["PostOffice"][0]

#         return {
#             "response": (
#                 f"PIN Code: {pin}\n"
#                 f"Place: {post_office['Name']}\n"
#                 f"District: {post_office['District']}\n"
#                 f"State: {post_office['State']}"
#             )
#         }

#     except Exception as e:
#         return {"response": f"Error fetching PIN data: {str(e)}"}

############
# import requests
# import re
# from app.registry import agent

# @agent("pincode")
# def pincode_agent(state):

#     text = state["user_query"]

#     match = re.search(r"\b\d{6}\b", text)

#     if not match:
#         return {"response": "Please provide a valid 6-digit PIN code."}

#     pin = match.group()

#     try:
#         url = f"https://api.postalpincode.in/pincode/{pin}"
#         res = requests.get(url, timeout=10)
#         data = res.json()

#         if data[0]["Status"] != "Success":
#             return {"response": f"No data found for PIN {pin}"}

#         post_office = data[0]["PostOffice"][0]

#         return {
#             "response": (
#                 f"PIN Code: {pin}\n"
#                 f"Place: {post_office['Name']}\n"
#                 f"District: {post_office['District']}\n"
#                 f"State: {post_office['State']}"
#             )
#         }

#     except Exception as e:
#         return {"response": f"Error fetching PIN data: {str(e)}"}


#########################
import requests
import re
import urllib3

from app.registry import agent

# Disable SSL warning
urllib3.disable_warnings(
    urllib3.exceptions.InsecureRequestWarning
)

@agent("pincode")
def pincode_agent(state):

    text = state["user_query"]

    # Extract 6-digit PIN code
    match = re.search(r"\b\d{6}\b", text)

    if not match:

        return {
            "response": "Please provide valid 6 digit PIN code"
        }

    pin = match.group()

    try:

        url = f"https://api.postalpincode.in/pincode/{pin}"

        response = requests.get(
            url,
            timeout=10,
            verify=False
        )

        data = response.json()

        if data[0]["Status"] != "Success":

            return {
                "response": f"No data found for PIN {pin}"
            }

        po = data[0]["PostOffice"][0]

        return {
            "response":
                f"PIN Code : {pin}\n"
                f"Place     : {po['Name']}\n"
                f"District  : {po['District']}\n"
                f"State     : {po['State']}"
        }

    except Exception as e:

        return {
            "response": f"Error fetching PIN data: {str(e)}"
        }