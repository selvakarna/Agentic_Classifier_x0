import asyncio
from app.registry import agent
from app.mcp_client import call_mcp

@agent("booking")
def booking(state):

    result = asyncio.run(call_mcp(
        "servers/booking_agent.py",
        "create_booking",
        {"service": "Hotel Room", "date": "Tomorrow"}
    ))

    return {"response": result}