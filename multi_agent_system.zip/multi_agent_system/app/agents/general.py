from app.registry import agent
from app.config import llm

@agent("general")
def general(state):
    res = llm.invoke(state["user_query"])
    return {"response": res.content}