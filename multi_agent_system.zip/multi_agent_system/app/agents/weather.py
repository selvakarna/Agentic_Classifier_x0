import re, asyncio
from app.registry import agent
from app.mcp_client import call_mcp

@agent("weather")
def weather(state):

    match = re.search(r"in\s+([a-zA-Z\s]+)", state["user_query"], re.I)
    location = match.group(1) if match else "India"

    result = asyncio.run(call_mcp(
        "servers/weather_agent.py",
        "get_weather",
        {"location": location}
    ))

    return {"response": result}